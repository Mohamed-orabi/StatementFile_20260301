create or replace package body REPEG47 as
  /****************************************************************************\
   Card Details
  ****************************************************************************
  ���������:
  ----------------------------------------------------------------------------
  ���        ����            ���ᠭ��
  ----------  ---------------  ---------------------------------------------
              �ਢ�襥�� �.�.  ���ࠡ�⪠
   27.09.05                    �������� ���� 宫��� �� ExtractDelay
   26.10.05                    ������� ��室���� 䠩�� �������� ��� ���ᠭ�� ������.
   30.11.05                    ����� ࠧ����� �� 2 ��� ���᪠ ������⮢ �� �������,
                               ���ਢ易���� � ����
                               ��������� ���� ����� �����, ���譨� ����� ���
   23.12.05                    ��������� ���� Remain ��� ����⮢�� ����
  \****************************************************************************/

  svidText      number;
  sBranch       number;
  sBranchName   varchar2(80);
  sCurrency     number;
  sPlanType     number;
  sOBJECT_TYPE  number;

  function  DialogParameters  return number;
  procedure Generate(pBeginDate in date);
  function  GetSumHold(pBeginDate in date,pAccount in varchar) return number;

procedure DialogExecProc
  (
    pWhat in char,
    pId   in number,
    pItem in varchar,
    pCmd  in number
  )
  is
    vId number;
  begin
    if pWhat = Dialog.wtDialogPre then
      svIdText := Text.Open('REPEG47');
    elsif pWhat = Dialog.wtDialogPost then
      Text.Close(svIdText);
    elsif pWhat = Dialog.wtItemPre then
      Dialog.SetItemDialog(pId, pItem, DialogParameters);
    elsif pWhat = Dialog.wtItemPost then
      vId := Dialog.GetItemDialog(pId, pItem);
      if Dialog.GetDialogCommand(vId) = Dialog.cmOk then
        Generate(Dialog.GetDate(pId,'Begindate'));
        Browser.ScrollerRefresh(pId,Dialog.FirstRecord);
      end if;
      Dialog.Destroy(vId);
      Dialog.SetItemDialog(pId, pItem, 0);
    end if;
  end;

function  DialogParameters
  return number is
    vId     number;
  begin
    vId := Dialog.New('Report parametrs', 0, 0, 35, 6);
    Dialog.InputDate(vId, 'BeginDate', 16, 2, 'Enter date','Date:');
    Dialog.PutDate(vId, 'BeginDate', Seance.GetOperDate);
    Dialog.Button(vId, 'Ok', 10, 4, 8, 'Ok', Dialog.cmOk, 0, 'Generate report');
    Dialog.Button(vId, 'Cancel', 20, 4, 9, 'Cancel', Dialog.cmCancel, 0, 'Cancel report generation');
    Dialog.SetItemAttributies(vId, 'Ok', Dialog.DefaultOn);
    Dialog.SetDialogPre(vId,'REPEG47.DialogParametersProc');
    Dialog.SetDialogValid(vId, 'REPEG47.DialogParametersProc');
    return vId;
  end;
procedure DialogParametersProc
  (
    pWhat in char,
    pId   in number,
    pItem in varchar,
    pCmd  in number
  )
  is
    vId          number;
    vBeginDate   date;
    vEndDate     date;
  begin
    if pWhat = Dialog.wtDialogValid then
      if Dialog.GetDate(pId,'Begindate') is null then
        Service.SayMsg(pId,'Error!','Starting date is not entered!~');
        Dialog.GoItem(pId,'Begindate');
        return;
      end if;
    end if;
  end;

procedure Generate
  (pBeginDate in date)
 is
 vItemCode number         := null;
 vVibCode  varchar2(2000) := null;

Cursor vCardDetail is
  select /*+ORDERED
            USE_NL(c)
            USE_NL(ac)
            USE_NL(a)
            USE_NL(ci)
            USE_NL(cl)
            FULL(C)
            INDEX_ASC(AC IACC2CARD_PAN_MBR)
            INDEX_ASC(A  IACCOUNT_ACCOUNTNO)
            INDEX_ASC(CI ICONTRACTITEM_KEY)
            INDEX_ASC(CL UK_CLIENTPERSONE)
          */
         a.AccountNo  Accno,
         A.CurrencyNo AccCurr,
         a.remain,
         c.Pan,
         c.MBR,
         c.CurrencyNo CardCurr,
         c.CardProduct,
         c.CreateDate,
         c.CancelDate,
         c.UpdateDate,
         c.CRD_STAT    Status,
         null          ContrNo,
         c.NameOnCard,
         cl.Countrycont,
         cl.Regioncont,
         cl.Citycont,
         cl.ZIPcont,
         cl.Addresscont,
         a.IdClient    IdCliAcc,
         c.IdClient    IdCliCard
    from tCard c, tAcc2Card ac, tAccount a,
         tClientPersone cl
   where c.Branch       = sBranch
     and c.CreateDate   < pBeginDate
     and (c.CloseDate   is null
      or (c.CloseDate   is null
     and  c.CloseDate   >= pBeginDate))
     and ac.Branch      = c.Branch
     and ac.PAN         = c.PAN
     and ac.MBR         = c.MBR
     and a.Branch       = ac.Branch
     and a.AccountNo    = ac.AccountNo
     --and a.IDclient in (643,128406)
     and cl.Branch      = a.Branch
     and cl.IdClient    = a.IdClient
     and not exists (select ci.key
                       from tContractItem ci
                      where ci.branch   = a.Branch
                        and ci.key      = a.Accountno
                        and ci.ItemType = 1
     )
   union
  select /*+ORDERED
            USE_NL(c)
            USE_NL(ci)
            USE_NL(ci2)
            USE_NL(a)
            USE_NL(cl)
            FULL(C)
            INDEX_ASC(CI  ICONTRACTITEM_KEY)
            INDEX_ASC(CI2 ICONTRACTITEM_NO)
            INDEX_ASC(A   IACCOUNT_ACCOUNTNO)
            INDEX_ASC(CL  UK_CLIENTPERSONE)
          */
         a.AccountNo  Accno,
         A.CurrencyNo AccCurr,
         a.remain,
         c.Pan,
         c.MBR,
         c.CurrencyNo CardCurr,
         c.CardProduct,
         c.CreateDate,
         c.CancelDate,
         c.UpdateDate,
         c.CRD_STAT    Status,
         ci.No         ContrNo,
         c.NameOnCard,
         cl.Countrycont,
         cl.Regioncont,
         cl.Citycont,
         cl.ZIPcont,
         cl.Addresscont,
         a.IdClient    IdCliAcc,
         c.IdClient    IdCliCard
    from tCard c, tContractItem ci,
         tContractItem ci2,  tAccount a, tClientPersone cl
   where c.Branch       = sBranch
     and c.CreateDate   < pBeginDate
     and (c.CloseDate   is null
      or (c.CloseDate   is null
     and  c.CloseDate   >= pBeginDate))
     and ci.BRANCH      = c.branch
     and substr(ci.key, 1, (length(ci.key)-1)) = c.pan
     and ci.ItemType    = 2                            -- ����, �ਢ易���� � ��������
     and ci2.Branch     = ci.Branch
     and ci2.No         = ci.No
     and ci2.ItemType   = 1
     and instr(vVibCode,'+'||ltrim(rtrim(to_char(ci2.itemcode)))||'+') != 0
     and a.Branch       = ci2.Branch
     and a.AccountNo    = ci2.Key
     --and a.IDclient in (643,128406)
     and cl.Branch      = a.Branch
     and cl.IdClient    = a.IdClient
   order by 1,2,3;

   vAccNoOld  varchar(30);
   vAccNoDOM  varchar(30);
   vAccNoINT  varchar(30);
   vContrType number;
   vCardName  varchar(100);
   vCardStat  varchar(100);
   vCountry   varchar(100);
   vRegion    varchar(100);
   vCity      varchar(100);
   vCustAddr  varchar(200);
   vMinDueAmount number;
   vCardLim      number;
   vPayDueDate   date;
   vLastStatDate date;
   vCashLimit    number;
   vSaleLimit    number;
   vRemCashLimit number;
   vRemSaleLimit number;
   oCredLimit     number;
   oCashLimit     number;
   oUsedCredLimit number;
   oUsedCashLimit number;
   vPrinz        varchar(4);
   vPrimFlag     varchar(1);
   vDirectRate   number;
   vSumHold      number;
 begin
  Text.Clear(svIdText);
  vVibCode := '+';
  for i in (Select distinct type
              from tContractTypeItems
             where branch = sBranch) loop
    vItemCode := DataMember.GetNumber(sOBJECT_TYPE,i.Type,'ItemDepositDom');
    if vItemCode is not null then
      vVibCode := vVibCode||ltrim(rtrim(to_char(vItemCode)))||'+';
    end if;
    vItemCode := DataMember.GetNumber(sOBJECT_TYPE,i.Type,'ItemDepositInt');
    if vItemCode is not null then
      vVibCode := vVibCode||ltrim(rtrim(to_char(vItemCode)))||'+';
    end if;
  end loop;
  s.say('vVibCode '||vVibCode,2);

  for i in vCardDetail loop
    if i.ContrNo is not null then
      s.say('i.ContrNo='||i.ContrNo||' i.PAN='||i.PAN,2);
      vContrType    := Contract.GetType(i.contrno);
      --if vContrType = 3905 then
      SCH_Customer.GetCardLimitValue(i.ContrNo, i.AccNo, i.PAN, i.MBR, oCredLimit, oCashLimit, oUsedCredLimit, oUsedCashLimit);
      vAccNoDOM     := Contract.GetAccountNoByItemName(i.contrno, 'ItemDepositDOM');
      --vAccNoINT     := Contract.GetAccountNoByItemName(i.contrno, 'ItemDepositINT');
      if i.AccNo = vAccNoDOM then
        vPrinz := 'DOM';
      else
        vPrinz := 'INT';
      end if;
      vDirectRate := ContractParams.LoadNumber(ContractParams.GetObjectType('CONTRACT_PROFILE'),
                                    ContractParams.LoadNumber(ContractParams.cContractType, vContrType,'Profile'||vPrinz), 'MinPayPrc');
      vDirectRate := nvl(vDirectRate,0);
      --end if;
      vCardLim   := nvl(oCredLimit,0);
      vSaleLimit := nvl(oCredLimit,0);
      vCashLimit := nvl(oCashLimit,0);
      vRemCashLimit := nvl(oCashLimit,0) - nvl(oUsedCashLimit,0);
      vRemSaleLimit := nvl(oCredLimit,0) - nvl(oUsedCredLimit,0);
      vMinDueAmount := nvl(SCH_Customer.GetUnpaidMinPayment(i.contrno,i.accno,pBeginDate),0);
      begin
       select t.StatementDate, st.DueDate into vLastStatDate, vPayDueDate
         from
          (select /*+ORDERED
                    USE_NL(tContractSTCycle)
                    INDEX_ASC(tContractSTCycle ICONTRACTSTCYCLE_CNO)*/
                  max(StatementDate) StatementDate
            from tContractSTCycle
            where branch        = sBranch
              and StatementDate <= pBeginDate
              and ContractNo    = i.ContrNo) t, tContractSTCycle st
        where st.branch        = sBranch
          and st.StatementDate = t.StatementDate
          and st.ContractNo    = i.ContrNo;
       exception
        when OTHERS then
          s.say('REPEG47.StatementDate Error:'||sqlErrm);
          null;
      end;
    else
      vDirectRate := 0;
      vCardLim    := i.Remain;
      vSaleLimit  := 0;
      vCashLimit  := 0;
      vRemCashLimit := 0;
      vRemSaleLimit := 0;
      vMinDueAmount := 0;
      vLastStatDate := null;
      vPayDueDate   := null;
    end if;
    if i.IdCliAcc = i.IdCliCard then
      vPrimFlag := 'P';
    else
      vPrimFlag := 'S';
    end if;
    vAccNoOld := nvl(Acc2Acc.GetOldAccountNo(i.AccNo), i.AccNo);
    vCardName := ReferenceCardProduct.Getname(i.CardProduct);
    vCardStat := ReferenceCRD_STAT.GetName(i.Status);
    vCountry  := ReferenceCountry.GetName(i.Countrycont);
    vRegion   := ReferenceRegion.GetName(i.Countrycont, i.Regioncont);
    vCity     := ReferenceCity.GetName(i.Countrycont, i.Regioncont,i.Citycont);
    vCustAddr := substr(vCountry,1,30)||' '||substr(vRegion,1,30)||' '||substr(vCity,1,25)||' '||substr(i.ZIPcont,1,10)||' '||substr(i.Addresscont,1,40);
    vSumHold  := GetSumHold(pBeginDate, i.AccNo);
    s.say('vSumHold='||vSumHold,2);
    Text.Append(svIdText,Service.RightPad(nvl(vAccNoOld,i.AccNo), 21,' ')|| Service.RightPad(ReferenceCurrency.GetAbbreviation(i.AccCurr), 3,' ')||'|'||
                         Service.RightPad(i.Pan, 20,' ')||'|'||
                         Service.RightPad(nvl(ReferenceCurrency.GetAbbreviation(i.CardCurr),' '), 3,' ')||'|'||
                         Service.RightPad(nvl(vCardName,' '), 30,' ')||'|'||
                         Service.RightPad(to_char(i.CreateDate,'dd/mm/yy'), 8,' ')||'|'||
                         Service.RightPad(to_char(i.CancelDate,'dd/mm/yy'), 8,' ')||'|'||
                         Service.RightPad(to_char(i.UpdateDate,'dd/mm/yy'), 8,' ')||'|'||
                         Service.LeftPad( to_char(vCardLim,'99999999990.00'), 16,' ')||'|'||
                         Service.LeftPad( to_char(vMinDueAmount,'99999999990.00'), 16,' ')||'|'||
                         Service.RightPad(nvl(to_char(vPayDueDate,'dd/mm/yy'),' '), 8,' ')||'|'||
                         Service.RightPad(nvl(to_char(vLastStatDate,'dd/mm/yy'),' '), 8,' ')||'|'||
                         Service.RightPad(nvl(i.NameOnCard,' '), 30,' ')||'|'||
                         Service.RightPad(nvl(vCardStat,' '), 15,' ')||'|'||
                         Service.LeftPad(to_char(nvl(-vSumHold, 0),'99999999990.00'), 17,' ')||'|'||
                         Service.LeftPad( to_char(vCashLimit,'99999999990.00'), 15,' ')||'|'||
                         Service.LeftPad( to_char(vSaleLimit,'99999999990.00'), 15,' ')||'|'||
                         Service.LeftPad( to_char(vRemCashLimit,'99999999990.00'), 15,' ')||'|'||
                         Service.LeftPad( to_char(vRemSaleLimit,'99999999990.00'), 15,' ')||'|'||
                         Service.RightPad(nvl(vCustAddr,' '), 125,' ')||'|'||
                         Service.RightPad(to_char(nvl(vDirectRate,0)), 1,' ')||'|'||
                         Service.RightPad(vPrimFlag, 1,' ')||'|'||
                         Service.RightPad(nvl(vAccNoOld,' '), 25,' ')||'|');
    vPrimFlag := null;
    vPrinz    := null;
  end loop;
 exception
   when others then
     s.say('REPEG47.Generate Error:'||sqlErrm);
     null;
 end;

function  GetSumHold
  (pBeginDate in date,
   pAccount   in varchar)
  return number
 is
 Cursor vHold is
   select decode(ltrim(rtrim(device))||ltrim(rtrim(entcode)),
          'B22',WithDrawal,
          'B23',WithDrawal,
          'P21',WithDrawal,
          'P22',WithDrawal,
          'V21',WithDrawal,
          'V22',WithDrawal,
                Value) ValueHold
     from tExtractDelay
    where branch           = sBranch
      and Docno            is Null
      and trunc(Operdate)  = pBeginDate
      and (CreditAccountNo = pAccount or
           DebitAccountNo  = pAccount);
 vSumHold number;
 begin
  vSumHold := 0;
  for i in vHold loop
    vSumHold := vSumHold + nvl(i.ValueHold,0);
  end loop;
  return vSumHold;
 exception
   when OTHERS then
   s.say('REPEG47.GetSumHold Error:'||sqlErrm);
   return vSumHold;
 end;--GetSumHold

function  GetCount
  return number is
  begin
    return Text.GetCount(svIdtext);
  end;
function  GetText
  (pNo in number)
  return varchar is
  begin
    return Text.GetText(svIdtext,pNo);
  end;

function  GetReportName
  return varchar is
  begin
    return 'Card Details';
  end;

procedure ExecReportOper (pOper number)
  is
    vCurParam    number;
    vBeginDate   date;
  begin

    /*if pOper = ReportBP.OP_GetParams then
      ReportBP.RegisterParam (param_BeginDate   , ReportBP.TYPE_DATE,  'Date: ', null, false, to_char(Seance.GetOperDate,ReportBP.DateFormat));

    els*/if pOper = ReportBP.OP_Generate then
      ReportBP.Message('Start generate');
      --������� ���祭�� ��� ��ࠬ��஢
      vBeginDate    := Seance.GetOperDate;--ReportBP.GetDateParam(param_BeginDate);

      svIdText := Text.Open('REPEG47');
      Generate(vBeginDate);
      Text.Close(svIdText);

      ReportBP.Message('Finish generate');
    end if;
 end;

begin
  sBranch     := Seance.GetBranch;
  sPlanType   := PlanAccount.TYPE_CLIENT;
  sBranchName := Seance.GetBranchName;
  sCurrency   := Seance.GetCurrency;
  sOBJECT_TYPE := Object.GetType(ContractType.OBJECT_NAME);
end;
/
show errors package body REPEG47;
